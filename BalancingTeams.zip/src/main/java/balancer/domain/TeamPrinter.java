package balancer.domain;

public interface TeamPrinter {
    void printTeams();
}
