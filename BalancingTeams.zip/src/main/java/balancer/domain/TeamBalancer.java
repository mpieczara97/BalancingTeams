package balancer.domain;

import java.util.List;

public interface TeamBalancer {
    List<Team> divideIntoTeams();
}
